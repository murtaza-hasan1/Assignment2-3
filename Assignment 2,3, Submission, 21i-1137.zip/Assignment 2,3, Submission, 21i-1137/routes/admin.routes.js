const express = require('express');
const router = express.Router();
const adminController = require('../controllers/admin.controller');
const authenticate = require('../middlewares/auth.middleware');

const isAdmin = (req, res, next) => {
  if (req.user.role === 'admin') {
    next(); 
  } else {
    res.status(403).json({ error: 'Permission Denied. User is not an admin.' });
  }
};

router.use(authenticate); 
router.get('/users', isAdmin, adminController.getAllUsers);
router.put('/block/:userId', isAdmin, adminController.blockUser);
router.get('/blog-posts', isAdmin, adminController.getAllBlogPosts);
router.get('/blog-posts/:postId', isAdmin, adminController.getBlogPost);
router.put('/disable-blog/:postId', isAdmin, adminController.disableBlog);

module.exports = router;
