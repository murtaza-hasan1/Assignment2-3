const express = require('express');
const router = express.Router();
const userController = require('../controllers/user.controller');
const authenticateUser = require('../middlewares/auth.middleware');

router.post('/follow/:id', authenticateUser, userController.followUser);
router.get('/feed', authenticateUser, userController.getUserFeed);
router.get('/notifications', authenticateUser, userController.getUserNotifications);

module.exports = router;
