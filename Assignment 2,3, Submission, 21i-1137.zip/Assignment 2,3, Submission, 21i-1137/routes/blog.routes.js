const express = require('express');
const router = express.Router();
const blogController = require('../controllers/blog.controller');
const authenticate = require('../middlewares/auth.middleware');

router.post('/create', authenticate, blogController.createBlogPost);
router.get('/list', blogController.getAllBlogPosts);
router.put('/update/:id', authenticate, blogController.updateBlogPost);
router.delete('/delete/:id', authenticate, blogController.deleteBlogPost);
router.post('/rate/:id', authenticate, blogController.rateBlogPost);
router.post('/comment/:id', authenticate, blogController.commentOnBlogPost);

module.exports = router;
