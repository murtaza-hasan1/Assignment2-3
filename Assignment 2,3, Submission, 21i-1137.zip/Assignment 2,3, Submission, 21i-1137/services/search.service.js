// search.service.js
const BlogPost = require('../models/BlogPost.model');

exports.searchBlogPosts = async (query) => {
  try {
    const searchResults = await BlogPost.find({
      $or: [
        { title: { $regex: new RegExp(query, 'i') } },
        { content: { $regex: new RegExp(query, 'i') } },
      ],
    });
    return searchResults;
  } catch (error) {
    throw error;
  }
};
