const mongoose = require('mongoose');
const User = require('../models/User.model');
const BlogPost = require('../models/BlogPost.model');

exports.followUser = async (req, res) => {
  try {
    console.log('Decoded Token:', req.user);

    const userIdToFollow = parseInt(req.params.id);

    if (isNaN(userIdToFollow) || userIdToFollow < 0) {
      console.log('Invalid user ID:', userIdToFollow);
      return res.status(400).json({ error: 'Invalid user ID' });
    }

    const userToFollow = await User.findOne({ userId: userIdToFollow });

    if (!userToFollow) {
      console.log('User not found with ID:', userIdToFollow);
      return res.status(404).json({ error: 'User not found' });
    }

    if (req.user.following.includes(userToFollow._id)) {
      return res.status(400).json({ error: 'User is already being followed' });
    }

    req.user.following.push(userToFollow._id);
    await req.user.save();

    userToFollow.followers.push(req.user._id);
    await userToFollow.save();

    res.json({ message: `Successfully followed user with ID: ${userIdToFollow}` });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

exports.getUserFeed = async (req, res) => {
  try {
    const user = await User.findById(req.user._id).populate('following');

    const followedUsers = user.following.map((followedUser) => followedUser._id);
    const userFeed = await BlogPost.find({ author: { $in: followedUsers } })
      .sort({ createdAt: -1 }) 
      .populate('author', 'username'); 

    res.json(userFeed);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

exports.getUserNotifications = async (req, res) => {
  try {
    const user = await User.findById(req.user._id).select('notifications');

    const userNotifications = user.notifications;
    res.json(userNotifications);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};
