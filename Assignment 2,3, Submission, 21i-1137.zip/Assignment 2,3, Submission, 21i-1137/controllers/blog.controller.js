const BlogPost = require('../models/BlogPost.model');
const User = require('../models/User.model');

exports.createBlogPost = async (req, res) => {
  try {
    const { title, content, authorId } = req.body;

    const user = await User.findOne({ userId: authorId });
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    const newBlogPost = new BlogPost({ title, content, author: user._id });
    await newBlogPost.save();

    res.status(201).json({ message: 'Blog post created successfully', blogPost: newBlogPost });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

exports.getAllBlogPosts = async (req, res) => {
  try {
    const { page = 1, limit = 10, sortBy, sortOrder, title } = req.query;
    const options = {
      limit: parseInt(limit),
      skip: (page - 1) * limit,
      sort: { [sortBy]: sortOrder === 'asc' ? 1 : -1 },
    };

    const query = title ? { title: { $regex: new RegExp(title), $options: 'i' } } : {};

    const blogPosts = await BlogPost.find(query, null, options).populate('author', 'username');

    res.status(200).json(blogPosts);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

exports.updateBlogPost = async (req, res) => {
  try {
    const { title, content } = req.body;
    const { id } = req.params;

    const blogPost = await BlogPost.findById(id);

    if (!blogPost.author.equals(req.user._id)) {
      return res.status(403).json({ error: 'Permission Denied' });
    }

    blogPost.title = title;
    blogPost.content = content;

    await blogPost.save();

    res.status(200).json({ message: 'Blog post updated successfully', blogPost });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

exports.deleteBlogPost = async (req, res) => {
  try {
    const { id } = req.params;
    const blogPost = await BlogPost.findById(id);
    if (!blogPost) {
      return res.status(404).json({ error: 'Blog post not found' });
    }
    if (!blogPost.author.equals(req.user._id)) {
      return res.status(403).json({ error: 'Permission Denied' });
    }
    await blogPost.remove();
    res.status(200).json({ message: 'Blog post deleted successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

exports.rateBlogPost = async (req, res) => {
  try {
    const { id } = req.params;
    const { value } = req.body;

    const blogPost = await BlogPost.findById(id);

    const existingRating = blogPost.rating.find((r) => r.user.equals(req.user._id));

    if (existingRating) {
      existingRating.value = value;
    } else {
      blogPost.rating.push({ user: req.user._id, value });
    }

    await blogPost.save();

    res.status(200).json({ message: 'Blog post rated successfully', blogPost });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

exports.commentOnBlogPost = async (req, res) => {
  try {
    const { id } = req.params;
    const { text } = req.body;

    const blogPost = await BlogPost.findById(id);

    const newComment = { user: req.user._id, text };
    blogPost.comments.push(newComment);

    await blogPost.save();

    const notificationMessage = `${req.user.username} commented on your blog post: "${blogPost.title}".`;
    const postAuthor = await User.findById(blogPost.author);
    postAuthor.notifications.push({ message: notificationMessage });
    await postAuthor.save();

    res.status(201).json({ message: 'Comment added successfully', comment: newComment });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};