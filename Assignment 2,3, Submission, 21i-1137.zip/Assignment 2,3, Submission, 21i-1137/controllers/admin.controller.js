const User = require('../models/User.model');
const BlogPost = require('../models/BlogPost.model');

exports.getAllUsers = async (req, res) => {
  try {
    const allUsers = await User.find();
    res.json(allUsers);
  } catch (error) {
    console.error('Error in getAllUsers:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

exports.blockUser = async (req, res) => {
  try {
    const blockedUser = await User.findByIdAndUpdate(
      req.params.userId,
      { $set: { role: 'blocked' } },
      { new: true }
    );

    if (!blockedUser) {
      res.status(404).json({ error: 'User not found' });
    } else {
      res.json(blockedUser);
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

exports.getAllBlogPosts = async (req, res) => {
  try {
    const allBlogPosts = await BlogPost.find({}, 'title author createdAt rating');
    res.json(allBlogPosts);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

exports.getBlogPost = async (req, res) => {
  try {
    const blogPost = await BlogPost.findById(req.params.postId);

    if (!blogPost) {
      res.status(404).json({ error: 'Blog post not found' });
    } else {
      res.json(blogPost);
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

exports.disableBlog = async (req, res) => {
  try {
    const disabledBlog = await BlogPost.findByIdAndUpdate(
      req.params.postId,
      { $set: { isDisabled: true } },
      { new: true }
    );

    if (!disabledBlog) {
      res.status(404).json({ error: 'Blog post not found' });
    } else {
      res.json(disabledBlog);
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};
