const BlogPost = require('../models/BlogPost.model');

exports.searchPosts = async (req, res) => {
  try {
    const { keyword, author, sortBy, sortOrder } = req.query;

    const searchQuery = {};

    if (keyword) {
      searchQuery.title = { $regex: new RegExp(keyword, 'i') };
    }

    if (author) {
      searchQuery.author = author;
    }

    const options = {
      sort: { [sortBy]: sortOrder === 'asc' ? 1 : -1 },
    };

    const searchResults = await BlogPost.find(searchQuery, null, options).populate('author', 'username');

    res.json(searchResults);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};
