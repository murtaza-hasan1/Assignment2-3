const User = require('../models/User.model');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const { JWT_SECRET } = process.env;

exports.register = async (req, res) => {
  try {
    const hashedPassword = await bcrypt.hash(req.body.password, 10);
    
    const userCount = await User.countDocuments();
    const newUser = await User.create({
      userId: userCount,
      username: req.body.username,
      email: req.body.email,
      password: hashedPassword,
      role: req.body.role,
    });

    res.json({ message: 'User registered successfully' });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ error: 'Failed to register user' });
  }
};

exports.login = async (req, res) => {
  try {
    const user = await User.findOne({ email: req.body.email });

    if (!user || !(await bcrypt.compare(req.body.password, user.password))) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    if (!user.token) {
      const token = jwt.sign({ userId: user.userId, role: user.role }, JWT_SECRET, { expiresIn: '24h' });
      user.token = token;
      await user.save();
    }

    res.json({ token: user.token });
  } catch (error) {
    console.error('Login Error:', error);
    res.status(500).json({ error: 'Failed to login' });
  }
};

exports.getProfile = async (req, res) => {
  try {
    const userId = req.params.id; 
    const userProfile = await User.findOne({ userId });

    if (!userProfile) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json(userProfile);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to retrieve user profile' });
  }
};

exports.updateProfile = async (req, res) => {
  try {
    const hashedPassword = await bcrypt.hash(req.body.password, 10);
    const updatedProfile = await User.findOneAndUpdate(
      { userId: req.params.id }, 
      {
        username: req.body.username,
        email: req.body.email,
        password: hashedPassword,
      },
      { new: true }
    );

    res.json(updatedProfile);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Failed to update user profile' });
  }
};
